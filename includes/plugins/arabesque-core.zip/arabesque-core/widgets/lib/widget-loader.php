<?php

if ( ! function_exists( 'arabesque_mikado_register_widgets' ) ) {
	function arabesque_mikado_register_widgets() {
		$widgets = apply_filters( 'arabesque_mikado_filter_register_widgets', $widgets = array() );

        if( arabesque_mikado_core_plugin_installed() ) {
            foreach ($widgets as $widget) {
                arabesque_mikado_create_wp_widget($widget);
            }
        }
	}
	
	add_action( 'widgets_init', 'arabesque_mikado_register_widgets' );
}