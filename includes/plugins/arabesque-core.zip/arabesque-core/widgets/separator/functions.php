<?php

if ( ! function_exists( 'arabesque_mikado_register_separator_widget' ) ) {
	/**
	 * Function that register separator widget
	 */
	function arabesque_mikado_register_separator_widget( $widgets ) {
		$widgets[] = 'ArabesqueMikadoSeparatorWidget';
		
		return $widgets;
	}
	
	add_filter( 'arabesque_mikado_filter_register_widgets', 'arabesque_mikado_register_separator_widget' );
}