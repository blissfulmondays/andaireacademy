<?php

include_once ARABESQUE_CORE_ABS_PATH . '/widgets/separator/functions.php';
include_once ARABESQUE_CORE_ABS_PATH . '/widgets/separator/separator.php';