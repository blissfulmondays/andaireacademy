<?php

include_once ARABESQUE_CORE_ABS_PATH . '/widgets/author-info/functions.php';
require_once ARABESQUE_CORE_ABS_PATH . '/widgets/author-info/author-info.php';