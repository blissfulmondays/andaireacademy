<?php

if ( ! function_exists( 'arabesque_mikado_register_author_info_widget' ) ) {
	/**
	 * Function that register author info widget
	 */
	function arabesque_mikado_register_author_info_widget( $widgets ) {
		$widgets[] = 'ArabesqueMikadoAuthorInfoWidget';
		
		return $widgets;
	}
	
	add_filter( 'arabesque_mikado_filter_register_widgets', 'arabesque_mikado_register_author_info_widget' );
}