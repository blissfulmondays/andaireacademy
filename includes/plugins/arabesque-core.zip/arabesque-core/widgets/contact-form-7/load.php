<?php

if ( arabesque_mikado_contact_form_7_installed() ) {
	include_once ARABESQUE_CORE_ABS_PATH . '/widgets/contact-form-7/contact-form-7.php';
	
	add_filter( 'arabesque_mikado_filter_register_widgets', 'arabesque_mikado_register_cf7_widget' );
}

if ( ! function_exists( 'arabesque_mikado_register_cf7_widget' ) ) {
	/**
	 * Function that register cf7 widget
	 */
	function arabesque_mikado_register_cf7_widget( $widgets ) {
		$widgets[] = 'ArabesqueMikadoContactForm7Widget';
		
		return $widgets;
	}
}