<?php if(arabesque_mikado_options()->getOptionValue('portfolio_single_hide_pagination') !== 'yes') : ?>
    <?php
    $back_to_link = get_post_meta(get_the_ID(), 'portfolio_single_back_to_link', true);
    $nav_same_category = arabesque_mikado_options()->getOptionValue('portfolio_single_nav_same_category') == 'yes';
    ?>
    <div class="mkdf-ps-navigation">
        <?php if(get_previous_post() !== '') : ?>
            <div class="mkdf-ps-prev">
                <?php if($nav_same_category) {
	                previous_post_link('%link','<span class="mkdf-ps-nav-mark"><svg version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px"
	 width="36px" height="42px" viewBox="0 0 36 42" enable-background="new 0 0 36 42" xml:space="preserve">
<g>
	<polygon fill="currentColor" points="22.534,39.053 3.458,21.265 22.155,3.471 22.845,4.196 4.917,21.257 23.216,38.322 	"/>
</g>
<g>
	<polygon fill="currentColor" points="30.884,39.053 11.808,21.265 30.505,3.471 31.194,4.196 13.266,21.257 31.565,38.322 	"/>
</g>
</svg></span>', true, '', 'portfolio-category');
                } else {
	                previous_post_link('%link','<span class="mkdf-ps-nav-mark"><svg version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px"
	 width="36px" height="42px" viewBox="0 0 36 42" enable-background="new 0 0 36 42" xml:space="preserve">
<g>
	<polygon fill="currentColor" points="22.534,39.053 3.458,21.265 22.155,3.471 22.845,4.196 4.917,21.257 23.216,38.322 	"/>
</g>
<g>
	<polygon fill="currentColor" points="30.884,39.053 11.808,21.265 30.505,3.471 31.194,4.196 13.266,21.257 31.565,38.322 	"/>
</g>
</svg></span>');
                } ?>
            </div>
        <?php endif; ?>

        <?php if($back_to_link !== '') : ?>
            <div class="mkdf-ps-back-btn">
                <a itemprop="url" href="<?php echo esc_url(get_permalink($back_to_link)); ?>">
                    <span class="social_flickr"></span>
                </a>
            </div>
        <?php endif; ?>

        <?php if(get_next_post() !== '') : ?>
            <div class="mkdf-ps-next">
                <?php if($nav_same_category) {
                    next_post_link('%link', '<span class="mkdf-ps-nav-mark"><svg version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px"
	 width="36px" height="42px" viewBox="0 0 36 42" enable-background="new 0 0 36 42" xml:space="preserve">
<g>
	<polygon fill="currentColor" points="13.489,39.053 32.564,21.265 13.868,3.471 13.179,4.196 31.107,21.257 12.808,38.322 	"/>
</g>
<g>
	<polygon fill="currentColor" points="5.14,39.053 24.215,21.265 5.519,3.471 4.829,4.196 22.758,21.257 4.458,38.322 	"/>
</g>
</svg></span>', true, '', 'portfolio-category');
                } else {
                    next_post_link('%link', '<span class="mkdf-ps-nav-mark"><svg version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px"
	 width="36px" height="42px" viewBox="0 0 36 42" enable-background="new 0 0 36 42" xml:space="preserve">
<g>
	<polygon fill="currentColor" points="13.489,39.053 32.564,21.265 13.868,3.471 13.179,4.196 31.107,21.257 12.808,38.322 	"/>
</g>
<g>
	<polygon fill="currentColor" points="5.14,39.053 24.215,21.265 5.519,3.471 4.829,4.196 22.758,21.257 4.458,38.322 	"/>
</g>
</svg></span>');
                } ?>
            </div>
        <?php endif; ?>
    </div>
<?php endif; ?>