<?php

get_header();

arabesque_mikado_get_title();

do_action('arabesque_mikado_action_before_main_content');

arabesque_core_get_single_portfolio();

get_footer();