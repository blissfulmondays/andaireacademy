<?php

include_once ARABESQUE_CORE_SHORTCODES_PATH . '/tabs/functions.php';
include_once ARABESQUE_CORE_SHORTCODES_PATH . '/tabs/tabs.php';
include_once ARABESQUE_CORE_SHORTCODES_PATH . '/tabs/tabs-item.php';