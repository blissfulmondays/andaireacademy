<div class="mkdf-separator-holder clearfix <?php echo esc_attr( $holder_classes ); ?>" <?php arabesque_mikado_inline_style( $holder_styles ); ?>>
	<?php if ( $enable_icon !== 'none' && $icon_position == 'left' ) { ?>
        <span class="mkdf-separator-icon" <?php arabesque_mikado_inline_style( $icon_holder_style ); ?>>
			<?php print wp_kses_post( $icon_html ); ?>
		</span>
	<?php } ?>
    <div data-width="<?php echo esc_attr( $width ); ?>" class="mkdf-separator" <?php arabesque_mikado_inline_style( $separator_styles ); ?>></div>
	<?php if ( $enable_icon !== 'none' && $icon_position !== 'left' ) { ?>
        <span class="mkdf-separator-icon" <?php arabesque_mikado_inline_style( $icon_holder_style ); ?>>
			<?php print wp_kses_post( $icon_html ); ?>
		</span>
		<?php if ( $icon_position == 'center' ) { ?>
            <div data-width=<?php echo esc_attr( $width ); ?> class="mkdf-separator" <?php arabesque_mikado_inline_style( $separator_styles ); ?>></div>
		<?php } ?>
	<?php } ?>
</div>
