<div class="mkdf-number-with-text-holder <?php echo esc_attr($holder_classes); ?>">
    <div class="mkdf-nwt-wrapper">
        <div class="mkdf-nwt-number-holder">
            <?php if(!empty($number)) { ?>
            <span class="mkdf-nwt-number"><?php echo esc_html($number); ?></span>
        <?php } ?>
        </div>

        <div class="mkdf-nwt-text-holder">
            <?php if(!empty($title)) { ?>
                <<?php echo esc_attr($title_tag); ?> class="mkdf-nwt-title" <?php echo arabesque_mikado_get_inline_style($title_styles); ?>><?php echo esc_html($title); ?></<?php echo esc_attr($title_tag); ?>>
            <?php } ?>
            <?php if(!empty($text)) { ?>
                <p class="mkdf-nwt-text" <?php echo arabesque_mikado_get_inline_style($text_styles); ?>><?php echo esc_html($text); ?></p>
            <?php } ?>
        </div>
    </div>
</div>

<?php /*elseif( !empty($image_hover['image_id'])):*/