(function($) {
    'use strict';

    var numberWithText = {};
    mkdf.modules.numberWithText = numberWithText;

    numberWithText.mkdfInitNumberWithText = mkdfInitNumberWithText;


    numberWithText.mkdfOnDocumentReady = mkdfOnDocumentReady;

    $(document).ready(mkdfOnDocumentReady);

    /*
     All functions to be called on $(document).ready() should be in this function
     */
    function mkdfOnDocumentReady() {
        mkdfInitNumberWithText();
    }

    /*
     **	Horizontal progress bars shortcode
     */
    function mkdfInitNumberWithText(){
        var numberWithText = $('.mkdf-number-with-text-holder.mkdf-number-with-text-animation-yes');

        if(numberWithText.length){
            numberWithText.each(function(index) {
                var thisNumberWithText = $(this),
                    timeout = 200;

                thisNumberWithText.appear(function() {
                    setTimeout((function() {
                        thisNumberWithText.animate({'opacity': 1}, mkdfGlobalVars.vars.mkdfElementAnimateDuration);
                    }), timeout * index);
                });
            });
        }
    }

})(jQuery);