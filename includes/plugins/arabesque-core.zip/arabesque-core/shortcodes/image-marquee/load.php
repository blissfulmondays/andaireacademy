<?php

include_once ARABESQUE_CORE_SHORTCODES_PATH . '/image-marquee/functions.php';
include_once ARABESQUE_CORE_SHORTCODES_PATH . '/image-marquee/image-marquee.php';