<?php

include_once ARABESQUE_CORE_SHORTCODES_PATH . '/working-hours/functions.php';
include_once ARABESQUE_CORE_SHORTCODES_PATH . '/working-hours/working-hours.php';