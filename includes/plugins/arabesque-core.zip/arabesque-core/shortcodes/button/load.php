<?php

include_once ARABESQUE_CORE_SHORTCODES_PATH . '/button/functions.php';
include_once ARABESQUE_CORE_SHORTCODES_PATH . '/button/button.php';